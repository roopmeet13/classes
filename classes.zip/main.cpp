
#include <iostream>

using namespace std;
class student{
    public:
    int rollno;
    string name;
};
int main()
{
    student brave;
    brave.rollno=56;
    brave.name="ROOP";
    cout<<brave.rollno<<" - "<<brave.name<<endl;

    return 0;
}